package com.example.and_demo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText mEmail, mPassword;
    Button Blogin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mEmail=findViewById(R.id.email);
        mPassword=findViewById(R.id.password);
        Blogin=findViewById(R.id.button);

        Blogin.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {

                String emailVal=mEmail.getText().toString().trim();
                String passVal=mPassword.getText().toString().trim();

                if(TextUtils.isEmpty(emailVal))
                {
                    mEmail.setError("Enter an email");
                    return;
                }
                if(TextUtils.isEmpty(passVal))
                {
                    mPassword.setError("Enter an password");
                    return;
                }

                if(emailVal.equals("abc@123.com") && passVal.equals("123456"))
                {
                    Toast.makeText(MainActivity.this, "Login successful",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), Sucsess.class));
                }
                else
                {
                    Toast.makeText(MainActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
                }
            }

        });

    }
}