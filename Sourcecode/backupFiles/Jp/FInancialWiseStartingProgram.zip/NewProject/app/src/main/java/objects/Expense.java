package objects;

import com.google.firebase.Timestamp;

public class Expense {
        private int expense;
        private String userId;
        private Timestamp timeAdded;
        private String userName;
        private String expenseType;


        public Expense() { //Empty constructor needed for working with firestore

        }

        public Expense(int expense, String userId, Timestamp timeAdded, String userName, String expenseType) {
            this.expense = expense;
            this.userId = userId;
            this.timeAdded = timeAdded;
            this.userName = userName;
            this.expenseType = expenseType;
        }

        public int getExpense() {
            return expense;
        }

        public void setExpense(int expense) {
            this.expense = expense;
        }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public Timestamp getTimeAdded() {
            return timeAdded;
        }

        public void setTimeAdded(Timestamp timeAdded) {
            this.timeAdded = timeAdded;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public String getExpenseType() {
            return expenseType;
        }

        public void setExpenseType(String expenseType) {
            this.expenseType = expenseType;
        }



}
