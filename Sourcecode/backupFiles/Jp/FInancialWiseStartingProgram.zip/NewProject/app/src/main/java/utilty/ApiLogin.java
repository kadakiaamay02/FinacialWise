package utilty;

import android.app.Application;

public class ApiLogin extends Application{
    private String username;
    private String userId;
    private String  userIncome;
    private String utaId;
    private String email;
    private static ApiLogin instance;

    public static ApiLogin getInstance()
    {
        if( instance == null )
            instance = new ApiLogin();
        return instance;
    }

    public ApiLogin(){} //Empty contsructor


    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getutaId() {
        return utaId;
    }

    public void setutaId(String utaId) {
        this.utaId = utaId;
    }

    public int getUserIncome(String userIncome) { return Integer.parseInt(userIncome); }

    public void setUserIncome(String userIncome){ this.userIncome = userIncome; }

    public String getUserEmail() {
        return email;
    }

    public void setUserEmail(String email) {
        this.email = email;
    }


}
