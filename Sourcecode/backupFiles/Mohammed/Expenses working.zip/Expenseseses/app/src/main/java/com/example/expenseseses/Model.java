package com.example.expenseseses;

import com.google.firebase.database.Exclude;

public class Model
{
    String itemName, itemAmount, itemDate, itemMethod, itemID;

    public Model() {
    }

    public Model(String itemName, String itemAmount, String itemDate, String itemMethod) {
        this.itemName = itemName;
        this.itemAmount = itemAmount;
        this.itemDate = itemDate;
        this.itemMethod = itemMethod;
        this.itemID = itemID;
    }

    public String getItemName() {
        return itemName;
    }

    public String getItemAmount() {
        return itemAmount;
    }

    public String getItemDate() {
        return itemDate;
    }

    public String getItemMethod() {
        return itemMethod;
    }

    public String getitemID() { return itemID; }

    public void setitemID(String itemID) { this.itemID = itemID; }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setItemAmount(String itemAmount) {
        this.itemAmount = itemAmount;
    }

    public void setItemDate(String itemDate) {
        this.itemDate = itemDate;
    }

    public void setItemMethod(String itemMethod) {
        this.itemMethod = itemMethod;
    }


}
