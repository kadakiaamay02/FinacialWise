package com.example.expenseseses;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder>
{
    private FirebaseDatabase db = FirebaseDatabase.getInstance();
    private DatabaseReference root = db.getReference().child("Users");
    ArrayList<Model> mList;
    Context context;
    String key = db.getReference("Users").getKey();

    public MyAdapter (Context context , ArrayList<Model> mList)
    {
        this.mList = mList;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        Model model = mList.get(position);
        holder.itemName.setText(model.getItemName());
        holder.itemAmount.setText(model.getItemAmount());
        holder.itemDate.setText(model.getItemDate());
        holder.itemMethod.setText(model.getItemMethod());




        holder.deleteButton.setOnClickListener(v -> {
            mList.remove(position);
            root.child(model.getitemID()).removeValue();
            notifyDataSetChanged();

        });

    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView itemName, itemAmount, itemDate, itemMethod;
        ImageView deleteButton;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            itemName = itemView.findViewById(R.id.itemNameText);
            itemAmount = itemView.findViewById(R.id.itemAmountText);
            itemDate = itemView.findViewById(R.id.itemDateText);
            itemMethod = itemView.findViewById(R.id.itemMethodText);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
